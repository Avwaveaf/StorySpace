package com.avwaveaf.storyspace.data.model

data class LoginRequest(
    val email: String,
    val password: String
)