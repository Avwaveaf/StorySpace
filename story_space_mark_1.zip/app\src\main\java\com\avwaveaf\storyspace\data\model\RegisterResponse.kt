package com.avwaveaf.storyspace.data.model

data class RegisterResponse(
    val error: Boolean,
    val message: String
)